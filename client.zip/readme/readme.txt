1. open the boostrapper

2. download the asset from tsar

3. open it 

4. enjoy